<?php
/**
  * osCommerce Online Merchant
  *
  * @copyright (c) 2016 osCommerce; https://www.oscommerce.com
  * @license MIT; https://www.oscommerce.com/license/mit.txt
  */

  require('includes/application.php');

  $page_contents = 'index.php';

  require('templates/main_page.php');
?>
