<div class="col-sm-<?php echo $content_width; ?> search">
  <?php echo $search_box; ?>
</div>

