<div class="col-sm-<?php echo $content_width; ?> breadcrumbs">
  <?php echo $breadcrumb->trail(' &raquo; '); ?>
</div>

