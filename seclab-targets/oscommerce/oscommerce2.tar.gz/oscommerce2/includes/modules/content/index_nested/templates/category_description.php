<div class="col-sm-<?php echo $content_width; ?> category-description">
  <div class="well well-sm">
    <?php echo $category['categories_description']; ?>
  </div>
</div>
