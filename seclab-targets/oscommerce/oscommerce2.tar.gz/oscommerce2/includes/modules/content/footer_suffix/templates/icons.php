<?php
use OSC\OM\OSCOM;
?>
<div class="col-sm-<?php echo $content_width; ?> text-right text-center-xs icons">
  <?php echo OSCOM::getDef('module_content_footer_extra_icons_text'); ?>
</div>
