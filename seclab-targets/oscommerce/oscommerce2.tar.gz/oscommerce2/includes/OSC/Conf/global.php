<?php
$ini = <<<EOD
db_server = ""
db_server_username = ""
db_server_password = ""
db_database = ""
db_table_prefix = ""
store_sessions = "MySQL"
time_zone = "Europe/Berlin"
EOD;
