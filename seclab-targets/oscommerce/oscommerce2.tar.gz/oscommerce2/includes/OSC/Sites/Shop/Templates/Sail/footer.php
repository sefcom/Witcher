</div>

<footer>
  <div class="footer">
    <div class="<?php echo BOOTSTRAP_CONTAINER; ?>">
      <div class="row">
        <?php echo $oscTemplate->getContent('footer'); ?>
      </div>
    </div>
  </div>
  <div class="footer-extra">
    <div class="<?php echo BOOTSTRAP_CONTAINER; ?>">
      <div class="row">
        <?php echo $oscTemplate->getContent('footer_suffix'); ?>
      </div>
    </div>
  </div>
</footer>
