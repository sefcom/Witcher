<div class="clearfix"></div>

<div id="contentText" class="container-fluid">
  <div class="pull-right text-right">
    <p style="color: #7a8996; border-top: 1px dotted #b2bac0; padding-top: 7px;"><i class="fa fa-heart"></i>, <a href="https://www.oscommerce.com" target="_blank" style="color: #7a8996">osCommerce</a></p>
  </div>
</div>
