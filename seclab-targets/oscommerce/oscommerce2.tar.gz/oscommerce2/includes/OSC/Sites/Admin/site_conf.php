<?php
$ini = <<<EOD
dir_root = ""
http_server = ""
http_path = ""
http_images_path = "images/"
http_cookie_domain = ""
http_cookie_path = ""
EOD;
