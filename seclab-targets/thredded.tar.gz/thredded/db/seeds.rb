# frozen_string_literal: true

require 'thredded/database_seeder'
Thredded::DatabaseSeeder.run
