# frozen_string_literal: true

module Thredded
  VERSION = '0.16.16'
end
