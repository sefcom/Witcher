These icons are copied from the Discourse repo:

https://github.com/discourse/discourse/tree/a43ec88f46b1698cb2fbd08983b715011f882c45/app/assets/images/favicons
