//= require thredded/dependencies/timeago
//= require thredded/dependencies/ujs
//= require thredded/dependencies/autosize
//= require thredded/dependencies/textcomplete

// We are not currently using any features that require the Babel polyfill
// Enable this if we do:
//- require babel/polyfill
