# frozen_string_literal: true

Rails.application.config.roadie.before_transformation = Thredded::EmailTransformer
