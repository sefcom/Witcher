# frozen_string_literal: true
Thredded::Engine.load_seed
