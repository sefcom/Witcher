# frozen_string_literal: true

module Themes
  VALID_THEMES = %w[day night].freeze
end
