# frozen_string_literal: true

module UsersHelper
  include ::Thredded::ApplicationHelper
end
