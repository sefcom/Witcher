require('@rails/ujs').start();
require('turbolinks').start();
require('monkey-patch-turbolinks.js');
require('thredded_imports.js');
