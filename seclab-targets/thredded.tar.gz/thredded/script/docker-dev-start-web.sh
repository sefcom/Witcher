#!/usr/bin/env bash

set -xeuo pipefail

# echo "GOOOOOOOOO"
sudo service mysql start

script/wait-for-tcp 127.0.0.1 3306

if ! [[ -f .db-created ]]; then
  bin/rails db:drop db:create
  touch .db-created
fi

bin/rails db:migrate

if ! [[ -f .db-seeded ]]; then
  bin/rails db:seed
  touch .db-seeded
fi

foreman start -f Procfile.docker.dev
