function SOAPGetDmzSettingsResponse(){
    this.Enabled = "";
    this.IPAddress = "";
};
function SOAPSetDmzSettings(){
    this.Enabled = "";
    this.IPAddress = "";
}
function SOAPGetLANIpSettingsResponse(){
    this.LANIPAddress = "";
}
function SOAPLANInfoResponse(){
    this.IPAddress = "";
};

function SOAPDmzSetResponse(){
   this.SetDMZSettingsResult=""
}