function SOAPGetFirewallSettingsResponse(){
    this.SPIIPv4 = "";
    this.AntiSpoof = "";
    this.WANPing = "";
}

function SOAPSetFirewallSettings(){
    this.SPIIPv4 = "";
    this.AntiSpoof = "";
    this.WANPing = "";
}
//配置状态返回
function SOAPFirewallStatue(){
    this.SetFirewallSettingsResult="";
}