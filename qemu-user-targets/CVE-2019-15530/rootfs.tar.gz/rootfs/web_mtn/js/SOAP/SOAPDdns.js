/**
 * Created by T-mark on 2017/8/29.
 */

/**
 * @constructor
 */
function SOAPGetDDNSSettingsResponse(){
    this.Enable = "";
    this.Provider = "";
    this.Hostname = "";
    this.Username = "";
    this.Password = "";

}

/**
 * @constructor
 */
function SOAPSetDDNSSettingsRequest(){
    this.Enable = "";
    this.Provider = "";
    this.Hostname = "";
    this.Username = "";
    this.Password = "";

}