/* Initial Javascript - JavaScript (Timmy Hsieh)*/
/* Code Number: 130916							*/
var iniDate = new Date().getTime();
var ini_ver = "?" + iniDate;
//var ini_ver = "?";//方便调试，展示不�?
document.write('<script type="text/javascript" charset="utf-8" src="js/jquery.cookie.js' + ini_ver + '"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="js/comm.js' + ini_ver + '"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="js/hmac_md5.js' + ini_ver + '"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="js/libajax.js' + ini_ver + '"></script>');
/*document.write('<script type="text/javascript" charset="utf-8" src="/js/hnap.js' + ini_ver + '"></script>');*/
document.write('<script type="text/javascript" charset="utf-8" src="js/i18n.js' + ini_ver + '"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="js/jquery.validate.js' + ini_ver + '"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="js/pagetool.js' + ini_ver + '"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="js/forbidview.js' + ini_ver + '"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="js/includeLang.js' + ini_ver + '"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="js/checkTimeout.js' + ini_ver + '"></script>');
document.write('<script type="text/javascript" charset="utf-8" src="js/SOAP/SOAPLogin.js' + ini_ver + '"></script>');
