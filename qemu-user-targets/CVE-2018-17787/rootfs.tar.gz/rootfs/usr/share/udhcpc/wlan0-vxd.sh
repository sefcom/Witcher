#!/bin/sh

exec /usr/share/udhcpc/wlan0-vxd.$1
