#!/bin/sh

exec /usr/share/udhcpc/br0.$1
