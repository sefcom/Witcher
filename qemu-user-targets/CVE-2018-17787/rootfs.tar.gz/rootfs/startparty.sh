#!/firmadyne/sh
set +e
if [ -L /etc/passwd ]; then
    echo "/etc/passwd is a symlink"
    cp /etc/passwd /tmp/old_passwd
    rm /etc/passwd
    echo "root:K.O9R/zqe0Hho:0:0:root:/root:/bin/ash" > /etc/passwd
    tail -n +2 /tmp/old_passwd >> /etc/passwd
fi
if [ ! -f /etc/passwd ]; then
    echo "no /etc/passwd"
    echo "root:K.O9R/zqe0Hho:0:0:root:/root:/bin/ash" > /etc/passwd
fi
if ! grep "root" /etc/passwd; then
    echo "root user missing from /etc/passwd"
    cp /etc/passwd /tmp/old_passwd
    echo "root:K.O9R/zqe0Hho:0:0:root:/root:/bin/ash" > /etc/passwd
    cat /tmp/old_passwd >> /etc/passwd
fi
echo "------ new /etc/passwd ---- "
cat /etc/passwd
echo "---------- "
if [ ! -f /bin/bash ]; then
    ln -s /bin/dash /bin/bash
fi
if (! pgrep -lf "3333" | grep -sqi "3333" ) ; then
    echo "Witcher: Bringing up nc listener on port 3333"
    /bin/nc -lv -p 3333 -e /bin/sh &
fi
echo "root:root" | /bin/chpasswd
if (pgrep -lf "telnetd" | grep -sqi "telnetd" ) ; then
    echo "Witcher: Bringing up telnetd on 23"
    /bin/telnetd &
else
    devip="$(ifconfig $(cat /firmadyne/net_bridge) | grep "inet addr" |cut -d ":" -f2|cut -d " " -f1)"
    echo "Witcher: Bringing up another telnetd on ${devip}:1337"
    /bin/telnetd -b ${devip}:1337 -l root &
fi
